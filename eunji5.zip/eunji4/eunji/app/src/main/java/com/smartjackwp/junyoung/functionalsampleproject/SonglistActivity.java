package com.smartjackwp.junyoung.functionalsampleproject;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class SonglistActivity extends AppCompatActivity {
    ListView listView;
    songAdapter adapter;
    String[] songs = {"나비야", "학교종", "퐁당퐁당"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songlist);

        listView = (ListView) findViewById(R.id.listView2);
        adapter = new songAdapter();
        listView.setAdapter(adapter);
    }

    class songAdapter extends BaseAdapter{
        @Override
        public int getCount() {
            return songs.length;
        }

        @Override
        public Object getItem(int position) {
            return songs[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView view = new TextView(getApplicationContext());
            view.setText(songs[position]);
            view.setTextSize(30.0f);
            view.setTextColor(Color.BLACK);
            return view;
        }
    }

    public void onClick(View view) {
        Intent intent = new Intent(this, PitchRealTimeGraphActivity.class);
        int checked = listView.getCheckedItemPosition();
        String ck = listView.getCheckedItemIds().toString();
        System.out.println(listView.getCheckedItemPosition());
        intent.putExtra("title", ck);
        System.out.println(ck);
        startActivity(intent);

        Log.v("Message", ck + "was selected");

        /*
        int len = listView.getCount();
        SparseBooleanArray ch = listView.getCheckedItemPositions();

        for (int i = 0; i < len; i++)
            if(ch.get(i)) {
                String item = listView.getAdapter().getItem(ch.keyAt(i)).toString();
                Log.v("Message", item + "was selected");
            }
        */
    }
}