package com.smartjackwp.junyoung.functionalsampleproject;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SonglistActivity extends AppCompatActivity {

    //http://blog.naver.com/PostView.nhn?blogId=rkdwnsdud555&logNo=220298826210 <-리스트뷰 참고

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songlist);
    }
}
