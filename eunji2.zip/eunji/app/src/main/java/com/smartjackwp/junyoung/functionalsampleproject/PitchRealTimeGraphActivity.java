package com.smartjackwp.junyoung.functionalsampleproject;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.util.ArrayList;

import be.tarsos.dsp.AudioDispatcher;
import be.tarsos.dsp.AudioEvent;
import be.tarsos.dsp.AudioProcessor;
import be.tarsos.dsp.io.android.AudioDispatcherFactory;
import be.tarsos.dsp.pitch.PitchDetectionHandler;
import be.tarsos.dsp.pitch.PitchDetectionResult;
import be.tarsos.dsp.pitch.PitchProcessor;

public class PitchRealTimeGraphActivity extends AppCompatActivity {
    private static final String TAG="Activity";
    Button recordButton;

    AudioDispatcher dispatcher;
    AudioProcessor pitchProcessor;
    Thread audioThread;

    GraphView realTimeGraph;
    GraphView staticGraph;

    Boolean recordState = false;

    private LineGraphSeries<DataPoint> realTimeSeries; //Series for real-time realTimeGraph
    private LineGraphSeries<DataPoint> staticSeries; //Series for static realTimeGraph
    private double graphLastXValue = 1d;
    private double staticGraphLastXValue = 1d;

    ArrayList<Point> recordedPoints;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pitch_real_time_graph);

        realTimeGraph = findViewById(R.id.realTimeGraph);
        //staticGraph = findViewById(R.id.staticGraph);

        staticSeries = new LineGraphSeries<>();
        staticSeries.setColor(Color.BLUE);
        staticSeries.setDataPointsRadius(50);
        staticSeries.setThickness(10);
        //staticGraph.addSeries(staticSeries);
        //staticGraph.getGridLabelRenderer().setHorizontalLabelsVisible(true);
        //staticGraph.getGridLabelRenderer().setVerticalLabelsVisible(true);
        //staticGraph.getViewport().setXAxisBoundsManual(true);
        //staticGraph.getViewport().setYAxisBoundsManual(true);
        //staticGraph.getViewport().setMinX(0);
        //staticGraph.getViewport().setMaxX(100);
        //staticGraph.getViewport().setMinY(-1);
        //staticGraph.getViewport().setMaxY(300);

        realTimeSeries = new LineGraphSeries<>();
        realTimeSeries.setColor(Color.rgb(0xF1,0x70,0x68));
        realTimeSeries.setDataPointsRadius(50);
        realTimeSeries.setThickness(10);
        //realTimeGraph.addSeries(realTimeSeries);
        //realTimeGraph.addSeries(staticSeries);

        realTimeGraph.getGridLabelRenderer().setHorizontalLabelsVisible(false);
        realTimeGraph.getGridLabelRenderer().setVerticalLabelsVisible(false);

        realTimeGraph.getViewport().setXAxisBoundsManual(true);
        realTimeGraph.getViewport().setYAxisBoundsManual(true);
        realTimeGraph.getViewport().setMinX(0);
        realTimeGraph.getViewport().setMaxX(100);
        realTimeGraph.getViewport().setMinY(0);
        realTimeGraph.getViewport().setMaxY(880);

        recordButton = findViewById(R.id.recordButton);
        recordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(recordState) //중지
                {
                    realTimeGraph.removeAllSeries();
                    graphLastXValue = 1d;
                    staticSeries.resetData(new DataPoint[] {});
                    realTimeSeries.resetData(new DataPoint[] {});
                    recordButton.setText("시작");
                    recordState = !recordState;
                }
                else //시작
                {
                    realTimeGraph.addSeries(realTimeSeries);
                    realTimeGraph.addSeries(staticSeries);
                    recordButton.setText("중지");
                    recordState = !recordState;
                }
            }
        });

        initPitcher();
    }

    @Override
    protected void onStop() {
        super.onStop();
        releaseDispatcher();
    }

    public void initPitcher()
    {
        dispatcher = AudioDispatcherFactory.fromDefaultMicrophone(22050, 1024, 0);

        PitchDetectionHandler pdh = new PitchDetectionHandler() {
            @Override
            public void handlePitch(PitchDetectionResult res, AudioEvent e){
                final float pitchInHz = res.getPitch();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        processPitch(pitchInHz);
                    }
                });
            }
        };
        pitchProcessor = new PitchProcessor(PitchProcessor.PitchEstimationAlgorithm.FFT_YIN, 22050, 1024, pdh);
        dispatcher.addAudioProcessor(pitchProcessor);
        audioThread = new Thread(dispatcher, "Audio Thread");
        audioThread.start();
    }

    public void processPitch(float pitchInHz){
        //Log.d(TAG,"hz ="+ pitchInHz);
        if (pitchInHz < 0)
            pitchInHz = 20;

        if(recordState)
        {
            graphLastXValue += 1d;
            realTimeSeries.appendData(new DataPoint(graphLastXValue, pitchInHz), true, 300);
            //staticGraphLastXValue += 1d;
            staticSeries.appendData(new DataPoint(graphLastXValue, graphLastXValue), true, 300);
            // recordedPoints.add(new Point(staticGraphLastXValue, 150));
            //System.out.println(pitchInHz);
        }
   }

    public void releaseDispatcher()
    {
        if(dispatcher != null)
        {
            if(!dispatcher.isStopped())
                dispatcher.stop();
            dispatcher = null;
        }
    }

    class Point{
        public double t;
        public float x;

        public Point(double t, float x)
        {
            this.t = t;
            this.x = x;
        }
    }
}