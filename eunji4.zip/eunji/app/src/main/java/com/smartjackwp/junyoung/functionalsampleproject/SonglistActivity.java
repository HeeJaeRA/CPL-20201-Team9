package com.smartjackwp.junyoung.functionalsampleproject;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class SonglistActivity extends AppCompatActivity {
    ListView listView;
    songAdapter adapter;
    String[] songs = {"나비야", "학교종", "퐁당퐁당", "꼬마 눈사람", "산토끼", "비행기"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songlist);

        listView = (ListView) findViewById(R.id.listView2);
        adapter = new songAdapter();
        listView.setAdapter(adapter);

    }

    public void onClick(View view) {
        //startActivity(new Intent("com.smartjackwp.junyoung.functionalsampleproject.PitchRealTimeGraphActivity"));
        startActivity(new Intent(this, PitchRealTimeGraphActivity.class));
        int checked = listView.getCheckedItemPosition();
    }

    class songAdapter extends BaseAdapter{
        @Override
        public int getCount() {
            return songs.length;
        }

        @Override
        public Object getItem(int position) {
            return songs[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView view = new TextView(getApplicationContext());
            view.setText(songs[position]);
            view.setTextSize(30.0f);
            view.setTextColor(Color.BLACK);

            return view;
        }
    }
}