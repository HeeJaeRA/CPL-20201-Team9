package com.smartjackwp.junyoung.functionalsampleproject;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

import be.tarsos.dsp.AudioDispatcher;
import be.tarsos.dsp.AudioEvent;
import be.tarsos.dsp.AudioProcessor;
import be.tarsos.dsp.io.android.AudioDispatcherFactory;
import be.tarsos.dsp.pitch.PitchDetectionHandler;
import be.tarsos.dsp.pitch.PitchDetectionResult;
import be.tarsos.dsp.pitch.PitchProcessor;

public class PitchRealTimeGraphActivity extends AppCompatActivity {
    private static final String TAG="Activity";
    Button recordButton;
    Button analysisButton;

    AudioDispatcher dispatcher;
    AudioProcessor pitchProcessor;
    Thread audioThread;

    GraphView realTimeGraph;
    GraphView staticGraph;

    Boolean recordState = false;

    private LineGraphSeries<DataPoint> realTimeSeries; //Series for real-time realTimeGraph
    private LineGraphSeries<DataPoint> staticSeries; //Series for static realTimeGraph
    private double graphLastXValue = 1d;
    private double staticGraphLastXValue = 1d;

    private int index = 0;

    ArrayList<Point> recordedPoints;
    ArrayList<Point> SoundPitchPoints;

    //ArrayList<Float> recordedPoints2;
//    float[] recordedPoints2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pitch_real_time_graph);

        realTimeGraph = findViewById(R.id.realTimeGraph);
        //staticGraph = findViewById(R.id.staticGraph);

        staticSeries = new LineGraphSeries<>();
        staticSeries.setColor(Color.BLUE);
        staticSeries.setDataPointsRadius(50);
        staticSeries.setThickness(10);

        realTimeSeries = new LineGraphSeries<>();
        realTimeSeries.setColor(Color.rgb(0xF1,0x70,0x68));
        realTimeSeries.setDataPointsRadius(50);
        realTimeSeries.setThickness(10);
        //realTimeGraph.addSeries(realTimeSeries);
        //realTimeGraph.addSeries(staticSeries);

        realTimeGraph.getGridLabelRenderer().setHorizontalLabelsVisible(false);
        realTimeGraph.getGridLabelRenderer().setVerticalLabelsVisible(false);

        realTimeGraph.getViewport().setXAxisBoundsManual(true);
        realTimeGraph.getViewport().setYAxisBoundsManual(true);
        realTimeGraph.getViewport().setMinX(0);
        realTimeGraph.getViewport().setMaxX(100);
        realTimeGraph.getViewport().setMinY(0);
        realTimeGraph.getViewport().setMaxY(880);

        staticGraphLastXValue = 1d;
        //System.out.println(staticGraphLastXValue);
        recordedPoints = new ArrayList<>();
        SoundPitchPoints = new ArrayList<>();
        for(int i=1; i<300; i++) {//300은 나중에 정답 파일 데이터 양만큼으로 바꿔야함
            Random rand = new Random();
            float pitchInHz = rand.nextFloat()*800+20;//일단 정답대신 20~820 랜덤 값으로 설정

            SoundPitchPoints.add(new Point(staticGraphLastXValue, pitchInHz));
            staticGraphLastXValue += 1d;
        }//여기서 정답 파일 읽어온 것 추가

        initPitcher();
    }

    public void onClick(View v) {
        recordButton = findViewById(R.id.recordButton);
        analysisButton = findViewById(R.id.analysisButton);
        switch(v.getId()) {
            case R.id.recordButton:
                if (recordState) //중지
                {
                    index = 0;
                    realTimeGraph.removeAllSeries();
                    graphLastXValue = 1d;
                    staticSeries.resetData(new DataPoint[]{});
                    realTimeSeries.resetData(new DataPoint[]{});
                    recordButton.setText("시작");
                    recordState = !recordState;
                } else //시작
                {
                    recordedPoints = new ArrayList<>();
                    realTimeGraph.addSeries(realTimeSeries);
                    realTimeGraph.addSeries(staticSeries);
                    recordButton.setText("중지");
                    recordState = !recordState;
                }
                break;
            case R.id.analysisButton:
                //System.out.println("분석");
                Intent intent = new Intent(this, AnalysisActivity.class);
//                System.out.println(recordedPoints.size());
//                for(int i=0; i<recordedPoints.size(); i++)
//                    System.out.println(recordedPoints.get(i).t);

//                for(int i=0; i<recordedPoints2.length; i++){
//                    System.out.println(recordedPoints2[i]);
//                }
                //intent.putExtra("recordedPoints", recordedPoints);//이게 왜 안되는지 모르겠
//                intent.putExtra("num", 100);
//                Bundle b = new Bundle();
//                intent.putExtra("bundle", b);
//                intent.putExtra("recordedPoints", recordedPoints2);
                //intent.putExtra("num", 1);

                startActivity(intent);
                finish();
                //analysisActivity로이동
                break;
        }
    }


    @Override
    protected void onStop() {
        super.onStop();
        releaseDispatcher();
    }

    public void initPitcher()
    {
        dispatcher = AudioDispatcherFactory.fromDefaultMicrophone(22050, 1024, 0);

        PitchDetectionHandler pdh = new PitchDetectionHandler() {
            @Override
            public void handlePitch(PitchDetectionResult res, AudioEvent e){
                final float pitchInHz = res.getPitch();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        processPitch(pitchInHz);
                    }
                });
            }
        };
        pitchProcessor = new PitchProcessor(PitchProcessor.PitchEstimationAlgorithm.FFT_YIN, 22050, 1024, pdh);
        dispatcher.addAudioProcessor(pitchProcessor);
        audioThread = new Thread(dispatcher, "Audio Thread");
        audioThread.start();
    }

    public void processPitch(float pitchInHz){
        //Log.d(TAG,"hz ="+ pitchInHz);
        if (pitchInHz < 0)
            pitchInHz = 20;

        if(recordState)
        {
            realTimeSeries.appendData(new DataPoint(graphLastXValue, pitchInHz), true, 300);
            staticSeries.appendData(new DataPoint(SoundPitchPoints.get(index).t, SoundPitchPoints.get(index).x), true, 300);//추가
            recordedPoints.add(new Point(graphLastXValue, pitchInHz)); //녹음된 주파수 저장->분석하기 눌렀을 때 전달(?)
            //recordedPoints2.add(pitchInHz);
//            int temp = recordedPoints2.length;
//            recordedPoints2[temp]=pitchInHz;
            graphLastXValue += 1d;
            index += 1;
            //System.out.println(pitchInHz);
        }
   }

    public void releaseDispatcher()
    {
        if(dispatcher != null)
        {
            if(!dispatcher.isStopped())
                dispatcher.stop();
            dispatcher = null;
        }
    }

    public class Point implements Serializable {
        public double t;
        public float x;

        public Point(double t, float x)
        {
            this.t = t;
            this.x = x;
        }
    }
}