package com.smartjackwp.junyoung.functionalsampleproject;

import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

import be.tarsos.dsp.AudioDispatcher;
import be.tarsos.dsp.AudioEvent;
import be.tarsos.dsp.AudioProcessor;
import be.tarsos.dsp.io.android.AudioDispatcherFactory;
import be.tarsos.dsp.pitch.PitchDetectionHandler;
import be.tarsos.dsp.pitch.PitchDetectionResult;
import be.tarsos.dsp.pitch.PitchProcessor;

public class PitchRealTimeGraphActivity extends AppCompatActivity {
    private static final String TAG="Activity";
    Button recordButton;
    Button analysisButton;

    AudioDispatcher dispatcher;
    AudioProcessor pitchProcessor;
    Thread audioThread;

    GraphView realTimeGraph;
    GraphView staticGraph;

    Boolean recordState = false;

    private LineGraphSeries<DataPoint> realTimeSeries; //Series for real-time realTimeGraph
    private LineGraphSeries<DataPoint> staticSeries; //Series for static realTimeGraph
    private double graphLastXValue = 1d;
    private double staticGraphLastXValue = 1d;

    private int index = 0;

    ArrayList<Point> recordedPoints;
    ArrayList<Point> SoundPitchPoints;

    float score = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pitch_real_time_graph);

        realTimeGraph = findViewById(R.id.realTimeGraph);
        //staticGraph = findViewById(R.id.staticGraph);

        staticSeries = new LineGraphSeries<>();
        staticSeries.setColor(Color.BLUE);
        staticSeries.setDataPointsRadius(50);
        staticSeries.setThickness(10);

        realTimeSeries = new LineGraphSeries<>();
        realTimeSeries.setColor(Color.rgb(0xF1,0x70,0x68));
        realTimeSeries.setDataPointsRadius(50);
        realTimeSeries.setThickness(10);
        //realTimeGraph.addSeries(realTimeSeries);
        //realTimeGraph.addSeries(staticSeries);

        realTimeGraph.getGridLabelRenderer().setHorizontalLabelsVisible(true);
        realTimeGraph.getGridLabelRenderer().setVerticalLabelsVisible(false);

        realTimeGraph.getViewport().setXAxisBoundsManual(true);
        realTimeGraph.getViewport().setYAxisBoundsManual(true);
        realTimeGraph.getViewport().setMinX(0);
        realTimeGraph.getViewport().setMaxX(100);
        realTimeGraph.getViewport().setMinY(0);
        realTimeGraph.getViewport().setMaxY(880);

        staticGraphLastXValue = 1d;
        //System.out.println(staticGraphLastXValue);
        recordedPoints = new ArrayList<>();
        SoundPitchPoints = new ArrayList<>();

        String fileName = "";
        Intent intent = getIntent();
        fileName = intent.getStringExtra("title");
        System.out.println(fileName);

        AssetManager am = getResources().getAssets();
        InputStream is = null;
        byte buf[] = new byte[1024];
        String text = "";

        try {
            is = am.open(fileName+".txt");

            BufferedReader bufrd = new BufferedReader(new InputStreamReader(is));
            String mLine;
            String array = "";
            int num = Integer.parseInt(bufrd.readLine());
            //System.out.println(num);
            while((mLine = bufrd.readLine())!=null){
                //System.out.println(mLine);
                array += mLine;
            }
            //System.out.println(array);
            //System.out.println(array.split(",").length);
            int i = 0;
            for(i=0; i<array.split(",").length; i++){
                for(int j=0; j<num; j++){
                    float pitchInHz = (float)Integer.parseInt(array.split(",")[i]);
                    //System.out.println(pitchInHz);
                    SoundPitchPoints.add(new Point(staticGraphLastXValue, pitchInHz));
                    staticGraphLastXValue += 1d;
                }
            }
            is.close();
        }catch(Exception e){
            e.printStackTrace();
        }

        initPitcher();
    }

    public void onClick(View v) {
        recordButton = findViewById(R.id.recordButton);
        analysisButton = findViewById(R.id.analysisButton);
        switch(v.getId()) {
            case R.id.recordButton:
                if (recordState) //중지
                {
                    index = 0;
                    realTimeGraph.removeAllSeries();
                    graphLastXValue = 1d;
                    staticSeries.resetData(new DataPoint[]{});
                    realTimeSeries.resetData(new DataPoint[]{});
                    recordButton.setText("시작");
                    recordState = !recordState;

                } else //시작
                {
                    recordedPoints = new ArrayList<>();
                    realTimeGraph.addSeries(realTimeSeries);
                    realTimeGraph.addSeries(staticSeries);
                    recordButton.setText("중지");
                    recordState = !recordState;
                }
                break;
            case R.id.analysisButton:
                //System.out.println("분석");
                Intent intent = new Intent(this, AnalysisActivity.class);
                System.out.println("버튼:"+score);
                intent.putExtra("score", score);

                startActivity(intent);
                finish();
                //analysisActivity로이동
                break;
        }
    }


    @Override
    protected void onStop() {
        super.onStop();
        releaseDispatcher();
    }

    public void initPitcher()
    {
        dispatcher = AudioDispatcherFactory.fromDefaultMicrophone(22050, 1024, 0);

        PitchDetectionHandler pdh = new PitchDetectionHandler() {
            @Override
            public void handlePitch(PitchDetectionResult res, AudioEvent e){
                final float pitchInHz = res.getPitch();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        processPitch(pitchInHz);
                    }
                });
            }
        };
        pitchProcessor = new PitchProcessor(PitchProcessor.PitchEstimationAlgorithm.FFT_YIN, 22050, 1024, pdh);
        dispatcher.addAudioProcessor(pitchProcessor);
        audioThread = new Thread(dispatcher, "Audio Thread");
        audioThread.start();
    }

    public void processPitch(float pitchInHz){
        //Log.d(TAG,"hz ="+ pitchInHz);
//        if (pitchInHz < 0)
//            pitchInHz = 20;

        if(pitchInHz>=260.12 && pitchInHz<291.97)
            pitchInHz = 261;
        else if(pitchInHz>=291.97 && pitchInHz<327.73)
            pitchInHz = 293;
        else if(pitchInHz>=327.73 && pitchInHz<347.22)
            pitchInHz = 329;
        else if(pitchInHz>=347.22 && pitchInHz<389.74)
            pitchInHz = 349;
        else if(pitchInHz>=389.74 && pitchInHz<437.47)
            pitchInHz = 392;
        else if(pitchInHz>=437.47 && pitchInHz<491.04)
            pitchInHz = 440;
        else if(pitchInHz>=491.04 && pitchInHz<520.24)
            pitchInHz = 493;
        else if(pitchInHz>=520.24 && pitchInHz<583.95)
            pitchInHz = 523;
        else if(pitchInHz>=583.95 && pitchInHz<655.46)
            pitchInHz = 587;
        else if(pitchInHz>=655.46 && pitchInHz<694.43)
            pitchInHz = 659;
        else if(pitchInHz>=694.43 && pitchInHz<779.48)
            pitchInHz = 698;
        else if(pitchInHz>=779.48 && pitchInHz<874.93)
            pitchInHz = 783;
        else if(pitchInHz>=874.93 && pitchInHz<982.08)
            pitchInHz = 880;
        else if(pitchInHz>=982.08 && pitchInHz<1040.47)
            pitchInHz = 987;
        else if(pitchInHz>=1040.47 && pitchInHz<1174.66)
            pitchInHz = 1046;
        else if(pitchInHz<0)
            pitchInHz=20;


        if(recordState)
        {
            realTimeSeries.appendData(new DataPoint(graphLastXValue, pitchInHz), true, 300);
            staticSeries.appendData(new DataPoint(SoundPitchPoints.get(index).t, SoundPitchPoints.get(index).x), true, 300);//추가
            recordedPoints.add(new Point(graphLastXValue, pitchInHz)); //녹음된 주파수 저장->분석하기 눌렀을 때 전달(?)

            if(pitchInHz == SoundPitchPoints.get(index).x){
                score += 1;
                System.out.println("score" + score);
            }
            //recordedPoints2.add(pitchInHz);
//            int temp = recordedPoints2.length;
//            recordedPoints2[temp]=pitchInHz;
            if(recordedPoints.size()==SoundPitchPoints.size()){//측정끝(중지X)

                score = ((float)score/recordedPoints.size()*100)+50;
                if(score>100)
                    score=100;
                System.out.println(score);

                index = 0;
                realTimeGraph.removeAllSeries();
                graphLastXValue = 1d;
                staticSeries.resetData(new DataPoint[]{});
                realTimeSeries.resetData(new DataPoint[]{});
                recordButton.setText("다시하기");
                recordState = !recordState;
            }

            graphLastXValue += 1d;
            index += 1;
            //System.out.println(pitchInHz);
        }
   }

    public void releaseDispatcher()
    {
        if(dispatcher != null)
        {
            if(!dispatcher.isStopped())
                dispatcher.stop();
            dispatcher = null;
        }
    }

    public class Point implements Serializable {
        public double t;
        public float x;

        public Point(double t, float x)
        {
            this.t = t;
            this.x = x;
        }
    }
}