package com.smartjackwp.junyoung.functionalsampleproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button recordPlayButton;
    Button pitchGraphButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recordPlayButton = findViewById(R.id.recordplayButton);
        pitchGraphButton = findViewById(R.id.pitchGraphButton);

        MOnCLickListener mOnCLickListener = new MOnCLickListener();
        recordPlayButton.setOnClickListener(mOnCLickListener);
        pitchGraphButton.setOnClickListener(mOnCLickListener);
    }

    class MOnCLickListener implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            switch (v.getId())
            {
                case R.id.recordplayButton:
                    startActivity(new Intent(MainActivity.this, SonglistActivity.class));
                    break;
                case R.id.pitchGraphButton:
                    startActivity(new Intent(MainActivity.this, SonglistActivity.class));
                    break;
//                case R.id.pitchGraphButton:
//                    startActivity(new Intent(MainActivity.this, PitchRealTimeGraphActivity.class));
//                    break;
            }
        }
    }
}
