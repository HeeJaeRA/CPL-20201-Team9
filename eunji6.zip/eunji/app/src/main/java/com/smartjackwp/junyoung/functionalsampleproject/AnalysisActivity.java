package com.smartjackwp.junyoung.functionalsampleproject;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.jjoe64.graphview.series.DataPoint;

import java.util.ArrayList;

public class AnalysisActivity extends AppCompatActivity {

    Button replayButton;

    //ArrayList<Float> recordedPoints;
    float score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analysis);

        //https://youngest-programming.tistory.com/28
        Intent intent = getIntent();
        score = intent.getFloatExtra("score", 1);
        System.out.println("분석:"+score);
        TextView textView = findViewById(R.id.textView4);
        textView.setText("점수 : "+(int)score);
        //Integer num = intent.getIntExtra("num",1);
//        Integer num = intent.getIntExtra("num", 1);
//        System.out.println(num);
//
//        Bundle b = getIntent().getExtras();
//        recordedPoints = b.getFloatArray("recordedPoints");
//        //ArrayList<Float> list = intent.getFloatArrayExtra("recordedPoints");
//        System.out.println(recordedPoints.length);
//        for(int i=0; i<recordedPoints.length; i++){
//            System.out.println(recordedPoints[i]);
//        }
        //recordedPoints = (ArrayList<PitchRealTimeGraphActivity.Point>)intent.getSerializableExtra("recordedPoints");
//
//        System.out.println(recordedPoints.size());
//        for(int i=0; i<recordedPoints.size(); i++)
//            System.out.println(recordedPoints.get(i).t+" "+recordedPoints.get(i).x);
    }

    public void onClick(View v) {
        replayButton = findViewById(R.id.recordButton);
        startActivity(new Intent(AnalysisActivity.this, PitchRealTimeGraphActivity.class));
        finish();
    }


}