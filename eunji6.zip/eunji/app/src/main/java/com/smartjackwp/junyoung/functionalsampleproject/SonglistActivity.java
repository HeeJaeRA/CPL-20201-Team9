package com.smartjackwp.junyoung.functionalsampleproject;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class SonglistActivity extends AppCompatActivity {
    ListView listView;
    songAdapter adapter;
    String[] songs = {"나비야", "학교종", "퐁당퐁당", "꼬마 눈사람", "산토끼", "비행기"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songlist);

        listView = (ListView) findViewById(R.id.listView2);
        adapter = new songAdapter();
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(clicklistner);
    }

    AdapterView.OnItemClickListener clicklistner = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            switch (position) {
                case 0 :
                    Intent navi = new Intent(SonglistActivity.this, PitchRealTimeGraphActivity.class);
                    Log.v("Message","나비야");
                    navi.putExtra("title", "나비야");
                    startActivity(navi);
                    break;
                case 1 :
                    Intent jong = new Intent(SonglistActivity.this, PitchRealTimeGraphActivity.class);
                    jong.putExtra("title", "학교종");
                    Log.v("Message","학교종");
                    startActivity(jong);
                    break;
                case 2:
                    Intent pong = new Intent(SonglistActivity.this, PitchRealTimeGraphActivity.class);
                    pong.putExtra("title", "퐁당퐁당");
                    Log.v("Message","퐁당퐁당");
                    startActivity(pong);
                    break;
                case 3:
                    Intent snow = new Intent(SonglistActivity.this, PitchRealTimeGraphActivity.class);
                    snow.putExtra("title", "꼬마 눈사람");
                    Log.v("Message","꼬마 눈사람");
                    startActivity(snow);
                    break;
                case 4:
                    Intent tokki = new Intent(SonglistActivity.this, PitchRealTimeGraphActivity.class);
                    tokki.putExtra("title", "산토끼");
                    Log.v("Message","산토끼");
                    startActivity(tokki);
                    break;
                case 5:
                    Intent fly = new Intent(SonglistActivity.this, PitchRealTimeGraphActivity.class);
                    fly.putExtra("title", "비행기");
                    Log.v("Message","비행기");
                    startActivity(fly);
                    break;
                default:
            }
        }
    };

    class songAdapter extends BaseAdapter{
        @Override
        public int getCount() {
            return songs.length;
        }

        @Override
        public Object getItem(int position) {
            return songs[position];
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView view = new TextView(getApplicationContext());
            view.setText(songs[position]);
            view.setTextSize(30.0f);
            view.setTextColor(Color.BLACK);
            return view;
        }
    }
}